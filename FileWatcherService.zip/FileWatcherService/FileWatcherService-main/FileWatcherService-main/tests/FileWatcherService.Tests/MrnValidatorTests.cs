﻿using FileWatcherService.Services;
using FileWatcherService.Utilities;
using FileWatcherService.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace FileWatcherService.Tests
{
    [TestFixture]
    public class MrnValidatorTests
    {
       

            [Test]
        public void TestMRNFormat_ValidFormat_Pass()
        {
            // Arrange
            string xmlContent = @"<medisight>
                                <directorate>OPH</directorate>
                                <department>CLI</department>
                                <mrn>0994h</mrn>
                                <documentreference>123456_20240319112716_02b19366-77b4-6df1-94be-6a51aab65902.pdf</documentreference>
                                <documentType>LCVGP</documentType>
                                <documentCategory>Strabismus And Paediatrics</documentCategory>
                                <encounterDate>20240319000000</encounterDate>
                                <signedDateTime>20240412122503</signedDateTime>
                                <consultantAD>BradleyP6</consultantAD>
                                <signerAD>BradleyP6</signerAD>
                                <GPGMC>G6846664</GPGMC>
                                <GPODS>A84007</GPODS>
                            </medisight>";
            // Load the XML content
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xmlContent);

            // Get the MRN node
            XmlNode mrnNode = xmlDoc.SelectSingleNode("//mrn");

            // Act
            bool isValid = MrnValidator.IsValid(mrnNode.ToString());

            // Assert
            Assert.That(!isValid, "MRN field should have a valid format.");
        }

    }

}
