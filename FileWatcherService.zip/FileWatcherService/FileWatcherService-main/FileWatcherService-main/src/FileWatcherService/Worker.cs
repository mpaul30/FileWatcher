using FileWatcherService.Models;
using FileWatcherService.Services;
using Microsoft.Extensions.Options;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Serilog;
using Microsoft.Extensions.Hosting;

namespace FileWatcherService
{
    public class Worker : BackgroundService
    {
        private readonly IFileProcessor _fileProcessor;
        private readonly FileWatcherSettings _settings;
        private readonly ILogger<BackgroundService> _logger;

        public Worker(IFileProcessor fileProcessor, IOptions<FileWatcherSettings> settings, ILogger<BackgroundService> logger)
        {
            _fileProcessor = fileProcessor;
            _settings = settings.Value;
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("BackgroundService is starting.");

            
            while (!stoppingToken.IsCancellationRequested)
            {
                var xmlFiles = Directory.GetFiles(_settings.InputFolder, "*.xml");

                try
                {
                    foreach (var xmlFilePath in xmlFiles)
                    {
                        if (File.Exists(xmlFilePath))
                        {
                            await _fileProcessor.ProcessFileAsync(xmlFilePath);
                        }
                    }


                    // Wait for a configured interval before checking again
                    await Task.Delay(_settings.CheckInterval, stoppingToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "An error occurred in Background service.");
                    // Handle specific exceptions or implement a retry logic here

                }
            }
        }
    }
}
