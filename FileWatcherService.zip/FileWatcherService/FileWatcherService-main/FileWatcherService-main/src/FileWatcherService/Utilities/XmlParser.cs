﻿using FileWatcherService.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace FileWatcherService.Utilities
{
    public class XmlParser : IXmlParser
    {
        public DocumentInfo Parse(string xmlFilePath)
        {
            var xdoc = XDocument.Load(xmlFilePath);
            string format = "yyyyMMddHHmmss";

            return new DocumentInfo
            {
                Mrn = xdoc.Root.Element("mrn").Value,
                DocumentType = xdoc.Root.Element("documentType").Value,
                Directorate = xdoc.Root.Element("directorate").Value,
                Department = xdoc.Root.Element("department").Value,
                DocumentReference = xdoc.Root.Element("documentreference").Value,
                DocumentCategory = xdoc.Root.Element("documentCategory").Value,
                EncounterDate = DateTime.ParseExact(xdoc.Root.Element("encounterDate").Value, format, CultureInfo.InvariantCulture),
                SignedDateTime = DateTime.ParseExact(xdoc.Root.Element("signedDateTime").Value, format, CultureInfo.InvariantCulture),
                ConsultantAD = xdoc.Root.Element("consultantAD").Value,
                SignerAD = xdoc.Root.Element("signerAD").Value,
                GPGMC = xdoc.Root.Element("GPGMC").Value,
                GPODS = xdoc.Root.Element("GPODS").Value

            };
        }
    }

}
