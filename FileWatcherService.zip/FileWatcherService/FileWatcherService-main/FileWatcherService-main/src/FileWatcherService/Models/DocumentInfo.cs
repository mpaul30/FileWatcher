﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileWatcherService.Models
{
    public class DocumentInfo
    {
        public required string Mrn { get; set; }
        public string DocumentType { get; set; }
        public DateTime EncounterDate { get; set; }
        public DateTime SignedDateTime { get; set; }
        public string Directorate { get; set; }
        public string Department { get; set; }
        public string DocumentReference { get; set; }
        public string DocumentCategory { get; set; }
        public required string ConsultantAD { get; set; }
        public required string SignerAD { get; set; }
        public string? GPGMC { get; set; }
        public string? GPODS { get; set; }

    }
}
