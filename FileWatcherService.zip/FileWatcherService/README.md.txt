# Introduction 
Program to watch an input folder for new files created by a clinical system. 

# Getting Started

1.	Create new background service : Using BackgroundService in .NET Core provides several benefits for implementing long-running background tasks like implementation of Dependency Injection. Offering Graceful shutdown as the ExecuteAsync method accepts CancellationToken that is triggered when the application is shutting down.In that way it handles application management too.
2.	Implemented Single Responsibility Principle by splitting classes based on its functionality like Xml parse, Mrn validation, File processing functionality etc.
3.	Tried to implement Interface Segregation Principle by dividing interfeces into small units as possible based on the functionality.
4. Implemented serilog as It needs minimal configuration. Configured Serilog using  appsettings.json files so that it will be easy to change log settings. Serilog supports a wide variety of sinks for log events such as files, databases, cloud services etc.


# Build and Test
Written unit tests with n unit testing - NUnit works with mocking frameworks such as Moq and dependency injection frameworks 

# Contribute
Implemented exception handling and logging

